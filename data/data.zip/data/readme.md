## Additional data: Large-scale interactive retrieval in art collections 


## Content:

* *brueghel5k_distractors.csv*: \
Contains the download links for the additional Wikiart [[1]](#1) images that serve 
as distractors. With these and images and annotations from the Brueghel dataset 
[[2,3]](#1,#2), our Brueghel5K dataset can be created.  

* *brueghel101k_distractors.csv*: \
Contains the download links for the additional Wikiart [[1]](#1) images that serve 
as distractors. With these and images and annotations from the Brueghel dataset 
[[2,3]](#1,#2), our Brueghel101K dataset can be created.  

* *ltll_query_bbs.csv*: \
Contains the additional query bounding boxes for the LTLL [[4]](#4) dataset that we 
use for the search across this dataset.  

* *style_classifier_wikiart_lables.csv*: \
Download links for the Wikiart [[1]](#1) images and style labels to train the style 
classification network. 


## Benchmark links:

For the Brueghel, LTLL, and Oxford5K dataset, we used the compilation of Shen et al. 
[3]. The links of the datasets can be found on their repository [5]. They are also
listed below:

* Brueghel [[2,3]](#1,#2): \
<https://www.dropbox.com/s/nljxhtct5d7285h/Brueghel.zip?dl=0>

* LTLL [[4]](#4): \
<https://www.dropbox.com/s/tvrt7v7m5kf1ssw/Ltll.zip?dl=0>

* Oxford5K [[6]](#5): \
<http://www.robots.ox.ac.uk/~vgg/data/oxbuildings/oxbuild_images.tgz>


## References
<a id="1">[1]</a> 
Wikiart,
<https://www.wikiart.org>, accessed: 2020-01-16

<a id="1">[2]</a> 
Brueghel family: Jan Brueghel the elder. The Brueghel family database. 
University of California, Berkeley,
<https://www.janbrueghel.net>

<a id="1">[3]</a> 
Discovering visual patterns in art collections with spatially-consistent feature learning.
Shen, Xi and Efros, Alexei A and Aubry, Mathieu. CVPR (2019)

<a id="1">[4]</a> 
Location recognition over large time lags.
Fernando, Basura and Tommasi, Tatiana and Tuytelaars, Tinne.
CVIU (2015)

<a id="1">[5]</a> 
Artminer,
<https://github.com/XiSHEN0220/ArtMiner>.
Shen, Xi. 
accessed: 2019-05-03

<a id="1">[6]</a> 
Object retrieval with large vocabularies and fast spatial matching.
Philbin, James and Chum, Ondrej and Isard, Michael and Sivic, Josef and Zisserman, Andrew.
CVPR (2017)

